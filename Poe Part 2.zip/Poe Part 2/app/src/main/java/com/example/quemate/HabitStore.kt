package com.example.quemate

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.UUID

data class Habit(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var category: String = "Other",
    var frequency: String = "Daily",
    var reminderTime: String = "",
    var targetStreak: Int = 0,
    var iconColor: String = "#7C3AED",
    var checkIns: MutableList<String> = mutableListOf(),
    var createdAt: String = LocalDate.now().toString()
) {
    fun completedToday(): Boolean = checkIns.contains(LocalDate.now().toString())
    fun currentStreak(): Int {
        var day = LocalDate.now()
        if (!checkIns.contains(day.toString())) day = day.minusDays(1)
        var streak = 0
        while (checkIns.contains(day.toString())) { streak++; day = day.minusDays(1) }
        return streak
    }
    fun bestStreak(): Int {
        if (checkIns.isEmpty()) return 0
        val days = checkIns.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.distinct().sorted()
        var best = 1; var run = 1
        for (i in 1 until days.size) {
            if (ChronoUnit.DAYS.between(days[i-1], days[i]) == 1L) { run++; best = maxOf(best, run) }
            else run = 1
        }
        return best
    }
    fun monthlyRate(): Int {
        val start = LocalDate.now().withDayOfMonth(1)
        val end = LocalDate.now()
        val totalDays = ChronoUnit.DAYS.between(start, end) + 1
        val done = checkIns.count { runCatching { LocalDate.parse(it) }.getOrNull()?.let { d -> !d.isBefore(start) && !d.isAfter(end) } == true }
        return if (totalDays == 0L) 0 else ((done * 100) / totalDays).toInt()
    }
}

object HabitStore {
    private const val PREFS = "streakforge_data"
    private const val KEY_HABITS = "habits"
    private const val KEY_XP = "xp"
    private const val KEY_NAME = "display_name"

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.contains(KEY_HABITS)) p.edit().putString(KEY_HABITS, "[]").putInt(KEY_XP, 0).apply()
    }
    fun displayName(ctx: Context): String = ctx.getSharedPreferences(PREFS,0).getString(KEY_NAME,"Forge User") ?: "Forge User"
    fun setDisplayName(ctx: Context, n: String) = ctx.getSharedPreferences(PREFS,0).edit().putString(KEY_NAME,n).apply()
    fun habits(ctx: Context): MutableList<Habit> {
        val a = JSONArray(ctx.getSharedPreferences(PREFS,0).getString(KEY_HABITS,"[]"))
        val out = mutableListOf<Habit>()
        for (i in 0 until a.length()) {
            val o=a.getJSONObject(i); val checks=mutableListOf<String>()
            val c=o.optJSONArray("checkIns") ?: JSONArray()
            for(j in 0 until c.length()) checks.add(c.getString(j))
            out.add(Habit(o.getString("id"),o.optString("name"),o.optString("category","Other"),o.optString("frequency","Daily"),o.optString("reminderTime",""),o.optInt("targetStreak",0),o.optString("iconColor","#7C3AED"),checks,o.optString("createdAt",LocalDate.now().toString())))
        }
        return out
    }
    private fun save(ctx: Context, list: List<Habit>) {
        val a=JSONArray()
        list.forEach { h -> val o=JSONObject(); o.put("id",h.id);o.put("name",h.name);o.put("category",h.category);o.put("frequency",h.frequency);o.put("reminderTime",h.reminderTime);o.put("targetStreak",h.targetStreak);o.put("iconColor",h.iconColor);o.put("createdAt",h.createdAt);o.put("checkIns",JSONArray(h.checkIns));a.put(o) }
        ctx.getSharedPreferences(PREFS,0).edit().putString(KEY_HABITS,a.toString()).apply()
    }
    fun upsert(ctx: Context, h: Habit) { val list=habits(ctx); val i=list.indexOfFirst{it.id==h.id}; if(i>=0) list[i]=h else list.add(h); save(ctx,list) }
    fun delete(ctx: Context,id:String) { save(ctx,habits(ctx).filter{it.id!=id}) }
    fun find(ctx: Context,id:String): Habit? = habits(ctx).firstOrNull{it.id==id}
    fun toggleToday(ctx: Context,id:String): Habit? {
        val h=find(ctx,id) ?: return null; val today=LocalDate.now().toString()
        if(h.checkIns.contains(today)) h.checkIns.remove(today) else { h.checkIns.add(today); addXp(ctx,10) }
        upsert(ctx,h); return h
    }
    fun xp(ctx: Context)=ctx.getSharedPreferences(PREFS,0).getInt(KEY_XP,0)
    fun level(ctx: Context)=xp(ctx)/100+1
    private fun addXp(ctx:Context, n:Int){val p=ctx.getSharedPreferences(PREFS,0);p.edit().putInt(KEY_XP,p.getInt(KEY_XP,0)+n).apply()}
    fun reset(ctx:Context){ctx.getSharedPreferences(PREFS,0).edit().clear().apply();init(ctx)}
}
