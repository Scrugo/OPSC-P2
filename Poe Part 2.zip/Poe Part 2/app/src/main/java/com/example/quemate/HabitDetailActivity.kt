package com.example.quemate
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate

class HabitDetailActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_detail);render()}
 private fun render(){
  val id=intent.getStringExtra("id")?:return;val h=HabitStore.find(this,id)?:return
  findViewById<TextView>(R.id.title).text=h.name
  findViewById<TextView>(R.id.category).text="${h.category} • ${h.frequency}"
  findViewById<TextView>(R.id.rate).text="${h.monthlyRate()}%"
  findViewById<com.google.android.material.progressindicator.CircularProgressIndicator>(R.id.ring).progress=h.monthlyRate()
  findViewById<TextView>(R.id.streak).text=h.currentStreak().toString()
  findViewById<TextView>(R.id.best).text=h.bestStreak().toString()
  findViewById<TextView>(R.id.completions).text="${h.checkIns.size} total completions"
  findViewById<TextView>(R.id.xp).text="${h.checkIns.size*10} XP earned"
  val chart=findViewById<LinearLayout>(R.id.weekChart); chart.removeAllViews()
  val today=LocalDate.now()
  for(i in 6 downTo 0){
   val d=today.minusDays(i.toLong()); val done=h.checkIns.contains(d.toString())
   val col=LinearLayout(this); col.orientation=LinearLayout.VERTICAL; col.gravity=android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
   val bar=TextView(this); bar.setBackgroundColor(if(done) Color.rgb(124,58,237) else Color.rgb(231,226,234))
   bar.layoutParams=LinearLayout.LayoutParams(0,if(done)70 else 20,1f).apply{setMargins(5,0,5,0)}
   col.addView(bar); val label=TextView(this);label.text=d.dayOfWeek.name.take(2);label.textSize=10f;label.gravity=17;col.addView(label)
   chart.addView(col,LinearLayout.LayoutParams(0,-1,1f))
  }
  findViewById<Button>(R.id.edit).setOnClickListener{startActivity(Intent(this,AddHabitActivity::class.java).putExtra("id",id))}
  findViewById<Button>(R.id.delete).setOnClickListener{HabitStore.delete(this,id);finish()}
 }
 override fun onResume(){super.onResume();if(!isFinishing)runCatching{render()}}
}