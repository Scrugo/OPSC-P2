package com.example.quemate

import android.app.*
import android.content.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.URL
import java.time.LocalDate
import kotlin.concurrent.thread

class MainActivity: AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var xpText: TextView
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);HabitStore.init(this)
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,android.Manifest.permission.POST_NOTIFICATIONS)!=0) ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),8)
        content=findViewById(R.id.content); xpText=findViewById(R.id.xpText)
        findViewById<Button>(R.id.navHome).setOnClickListener{showDashboard()}
        findViewById<Button>(R.id.navMotivation).setOnClickListener{showMotivation()}
        findViewById<Button>(R.id.navProfile).setOnClickListener{showProfile()}
        findViewById<Button>(R.id.addFab).setOnClickListener{startActivity(Intent(this,AddHabitActivity::class.java))}
        showDashboard()
    }
    override fun onResume(){super.onResume();if(::content.isInitialized)showDashboard()}
    private fun showDashboard(){
        findViewById<TextView>(R.id.screenTitle).text="Today"
        findViewById<Button>(R.id.addFab).visibility=View.VISIBLE
        content.removeAllViews()
        val habits=HabitStore.habits(this)
        xpText.text="Level ${HabitStore.level(this)}  •  ${HabitStore.xp(this)} XP"
        if(habits.isEmpty()){val t=TextView(this);t.text="No habits yet.\nTap + to forge your first habit.";t.textSize=18f;t.setPadding(24,48,24,24);content.addView(t)}
        habits.forEach{h->
            val card=layoutInflater.inflate(R.layout.habit_card,content,false)
            card.findViewById<TextView>(R.id.habitName).text=h.name
            card.findViewById<TextView>(R.id.habitMeta).text="${h.category}  •  ${h.currentStreak()} day streak"
            val done=card.findViewById<CheckBox>(R.id.done)
            done.isChecked=h.completedToday()
            done.setOnClickListener{HabitStore.toggleToday(this,h.id);showDashboard()}
            card.setOnClickListener{startActivity(Intent(this,HabitDetailActivity::class.java).putExtra("id",h.id))}
            content.addView(card)
        }
    }
    private fun showMotivation(){
        findViewById<TextView>(R.id.screenTitle).text="Daily Motivation";findViewById<Button>(R.id.addFab).visibility=View.GONE;content.removeAllViews()
        val quote=layoutInflater.inflate(R.layout.motivation_view,content,false);content.addView(quote)
        val text=quote.findViewById<TextView>(R.id.quoteText);val author=quote.findViewById<TextView>(R.id.quoteAuthor)
        fun load(){text.text="Loading…";author.text="";thread{try{val raw=URL("https://api.quotable.io/random").readText();val o=JSONObject(raw);runOnUiThread{text.text="“${o.optString("content")}”";author.text="— ${o.optString("author")}"}}catch(e:Exception){runOnUiThread{text.text="Keep going. Small actions build lasting routines.";author.text="— StreakForge"}}}}
        quote.findViewById<Button>(R.id.newQuote).setOnClickListener{load()};quote.findViewById<Button>(R.id.shareQuote).setOnClickListener{val s=Intent(Intent.ACTION_SEND);s.type="text/plain";s.putExtra(Intent.EXTRA_TEXT,text.text+" "+author.text);startActivity(Intent.createChooser(s,"Share quote"))};load()
    }
    private fun showProfile(){
        findViewById<TextView>(R.id.screenTitle).text="Profile";findViewById<Button>(R.id.addFab).visibility=View.GONE;content.removeAllViews()
        val v=layoutInflater.inflate(R.layout.profile_view,content,false);content.addView(v)
        v.findViewById<TextView>(R.id.profileName).text=HabitStore.displayName(this)
        v.findViewById<TextView>(R.id.profileStats).text="Level ${HabitStore.level(this)}  •  ${HabitStore.xp(this)} XP  •  ${HabitStore.habits(this).size} habits"
        v.findViewById<Button>(R.id.signOut).setOnClickListener{startActivity(Intent(this,LoginActivity::class.java));finish()}
        v.findViewById<Button>(R.id.resetData).setOnClickListener{HabitStore.reset(this);showDashboard()}
    }
}