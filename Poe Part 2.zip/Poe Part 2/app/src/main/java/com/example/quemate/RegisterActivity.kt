package com.example.quemate
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity: AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_register)
  findViewById<Button>(R.id.createButton).setOnClickListener{
   val n=findViewById<EditText>(R.id.fullName).text.toString().trim()
   if(n.isEmpty()){findViewById<EditText>(R.id.fullName).error="Name required";return@setOnClickListener}
   HabitStore.setDisplayName(this,n); startActivity(Intent(this,MainActivity::class.java));finishAffinity()
  }
 }
}