package com.example.quemate
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*
class AddHabitActivity:AppCompatActivity(){
 private var id:String?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_add_habit);id=intent.getStringExtra("id");val existing=id?.let{HabitStore.find(this,it)}
  val name=findViewById<EditText>(R.id.name);val category=findViewById<Spinner>(R.id.category);val frequency=findViewById<Spinner>(R.id.frequency);val reminder=findViewById<TextView>(R.id.reminder);val target=findViewById<EditText>(R.id.target)
  category.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Health","Study","Mind","Other"))
  frequency.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Daily","Weekdays","3 times/week","5 times/week"))
  existing?.let{ name.setText(it.name);category.setSelection((category.adapter as ArrayAdapter<String>).getPosition(it.category));frequency.setSelection((frequency.adapter as ArrayAdapter<String>).getPosition(it.frequency));reminder.text=it.reminderTime.ifBlank{"No reminder"};target.setText(if(it.targetStreak>0)it.targetStreak.toString() else "")}
  reminder.setOnClickListener{val c=Calendar.getInstance();TimePickerDialog(this,{_,h,m->reminder.text=String.format("%02d:%02d",h,m)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()}
  findViewById<Button>(R.id.saveHabit).setOnClickListener{if(name.text.toString().trim().isEmpty()){name.error="Habit name required";return@setOnClickListener};val h=existing?:Habit(name=name.text.toString());h.name=name.text.toString();h.category=category.selectedItem.toString();h.frequency=frequency.selectedItem.toString();h.reminderTime=if(reminder.text=="No reminder")"" else reminder.text.toString();h.targetStreak=target.text.toString().toIntOrNull()?:0;HabitStore.upsert(this,h);ReminderReceiver.schedule(this,h);finish()}
 }
}