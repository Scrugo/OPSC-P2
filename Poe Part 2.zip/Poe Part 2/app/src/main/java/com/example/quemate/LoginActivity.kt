package com.example.quemate
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity: AppCompatActivity() {
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_login);HabitStore.init(this)
   findViewById<Button>(R.id.loginButton).setOnClickListener{
     val name=findViewById<EditText>(R.id.email).text.toString().substringBefore("@").ifBlank{"Forge User"}
     HabitStore.setDisplayName(this,name.replaceFirstChar{it.uppercase()})
     startActivity(Intent(this,MainActivity::class.java));finish()
   }
   findViewById<TextView>(R.id.signupLink).setOnClickListener{startActivity(Intent(this,RegisterActivity::class.java))}
 }
}