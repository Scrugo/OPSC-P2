package com.example.quemate
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
import java.util.*
class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){val name=i.getStringExtra("name")?:"Habit";val channel="streakforge_reminders";val nm=c.getSystemService(NotificationManager::class.java);if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(channel,"Habit reminders",NotificationManager.IMPORTANCE_HIGH));val n=NotificationCompat.Builder(c,channel).setSmallIcon(R.drawable.ic_streakforge).setContentTitle("StreakForge reminder").setContentText("Time to check in: $name").setAutoCancel(true).build();if(android.os.Build.VERSION.SDK_INT<33||c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==0)nm.notify(name.hashCode(),n)}
 companion object{
  fun schedule(c:Context,h:Habit){if(h.reminderTime.isBlank())return;val parts=h.reminderTime.split(":");val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,parts[0].toInt());set(Calendar.MINUTE,parts[1].toInt());set(Calendar.SECOND,0);if(before(Calendar.getInstance()))add(Calendar.DAY_OF_YEAR,1)};val pi=PendingIntent.getBroadcast(c,h.id.hashCode(),Intent(c,ReminderReceiver::class.java).putExtra("name",h.name),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);c.getSystemService(AlarmManager::class.java).setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)}
 }
}